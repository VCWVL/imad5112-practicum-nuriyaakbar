package com.example.musicplaylstmanager

import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class DetailActivity : AppCompatActivity() {

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_screen2)

        val showButton = findViewById<Button>(R.id.btnShow)
        val avgButton = findViewById<Button>(R.id.btnAverage)
        val returnButton = findViewById<Button>(R.id.btnReturn)
        val textView = findViewById<TextView>(R.id.tvDetails)

        showButton.setOnClickListener {
            val details = StringBuilder()
            for ((index, song) in MainActivity.playlist.withIndex()) {
                details.append("Song ${index + 1}:\nTitle: ${song.title}\nArtist: ${song.artist}\nRating: ${song.rating}\nComments: ${song.comments}\n\n")
            }
            textView.text = details.toString()
        }

        avgButton.setOnClickListener {
            val totalRating = MainActivity.playlist.sumOf { it.rating }
            val avg = if (MainActivity.playlist.isNotEmpty()) totalRating.toDouble() / MainActivity.playlist.size else 0.0
            textView.text = "Average Rating: %.2f".format(avg)
        }

        returnButton.setOnClickListener {
            finish()
        }
    }
}


