package com.example.musicplaylstmanager

import android.annotation.SuppressLint
import android.content.Intent
import android.os.Bundle
import android.widget.*
import androidx.appcompat.app.AppCompatActivity

class MainActivity : AppCompatActivity() {

    companion object {
        val playlist = mutableListOf<Song>()
    }

    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)

        val addButton = findViewById<Button>(R.id.btnAdd)
        val nextButton = findViewById<Button>(R.id.btnNext)
        val exitButton = findViewById<Button>(R.id.btnExit)

        addButton.setOnClickListener {
            if (playlist.size >= 4) {
                Toast.makeText(this, "Only 4 songs allowed.", Toast.LENGTH_SHORT).show()
                return@setOnClickListener
            }

            val dialogView = layoutInflater.inflate(R.layout.layout, null)
            val dialogBuilder = android.app.AlertDialog.Builder(this)
                .setTitle("Add Song")
                .setView(dialogView)
                .setPositiveButton("Add") { _, _ ->
                    val title = dialogView.findViewById<EditText>(R.id.etTitle).text.toString()
                    val artist = dialogView.findViewById<EditText>(R.id.etArtist).text.toString()
                    val rating = dialogView.findViewById<EditText>(R.id.etRating).text.toString().toIntOrNull() ?: 0
                    val comments = dialogView.findViewById<EditText>(R.id.etComments).text.toString()

                    if (title.isNotBlank() && artist.isNotBlank() && rating in 1..5) {
                        playlist.add(Song(title, artist, rating, comments))
                        Toast.makeText(this, "Song added!", Toast.LENGTH_SHORT).show()
                    } else {
                        Toast.makeText(this, "Please enter valid details", Toast.LENGTH_SHORT).show()
                    }
                }
                .setNegativeButton("Cancel", null)

            dialogBuilder.show()
        }

        nextButton.setOnClickListener {
            startActivity(Intent(this, DetailActivity::class.java))
        }

        exitButton.setOnClickListener {
            finishAffinity()
        }
    }
}

data class Song(val title: String, val artist: String, val rating: Int, val comments: String)

